# 5DOF Robotic Arm

This project contains the design files and code for a 5 degree of freedom robotic arm.